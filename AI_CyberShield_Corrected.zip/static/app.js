const urlForm = document.getElementById("url-form");
const textForm = document.getElementById("text-form");
const urlInput = document.getElementById("url-input");
const textInput = document.getElementById("text-input");
const urlResult = document.getElementById("url-result");
const textResult = document.getElementById("text-result");
const totalScans = document.getElementById("total-scans");
const historyBox = document.getElementById("history");
let scans = 0;
let historyItems = [];

function safeText(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}
function setLoading(button, loading, text) {
  button.disabled = loading;
  const label = button.querySelector(".button-text");
  if (label) label.textContent = loading ? "Scanning…" : text;
}
function renderResult(container, data, type) {
  container.classList.remove("hidden");
  if (!data.ok) {
    container.innerHTML = `<div class="result-head"><h3>Could not analyze</h3></div><p class="result-note">${safeText(data.error || "Please try again.")}</p>`;
    return;
  }
  const level = data.level || "low";
  const title = type === "url" ? data.label : `Message risk: ${level.toUpperCase()}`;
  const reasons = type === "url"
    ? data.reasons
    : data.findings.map(f => f.matches.length ? `${f.title}: ${f.matches.join(", ")}` : f.title);
  container.innerHTML = `
    <div class="result-head"><h3>${safeText(title)}</h3><span class="score-pill ${level}">Risk score: ${data.score}/100</span></div>
    <div class="score-track"><div class="score-fill ${level}" style="width:${data.score}%"></div></div>
    <b style="font-size:11px">Findings</b>
    <ul>${reasons.map(r => `<li>${safeText(r)}</li>`).join("")}</ul>
    <div class="result-note">${safeText(data.note || "")}</div>`;
}
function addHistory(title, level, score) {
  scans++;
  totalScans.textContent = String(scans).padStart(2, "0");
  historyItems.unshift({title, level, score, time: new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})});
  historyItems = historyItems.slice(0, 5);
  historyBox.innerHTML = historyItems.map(item => `
    <div class="history-item"><span class="history-mark">⌁</span><div>
      <b>${safeText(item.title)}</b><small>${safeText(item.time)}</small>
      <div class="risk" style="color:${item.level === "high" ? "var(--red)" : item.level === "medium" ? "var(--amber)" : "var(--green)"}">${item.level.toUpperCase()} · ${item.score}/100</div>
    </div></div>`).join("");
}
urlForm.addEventListener("submit", async event => {
  event.preventDefault();
  const button = urlForm.querySelector("button");
  setLoading(button, true, "Analyze Threat");
  urlResult.classList.remove("hidden");
  urlResult.innerHTML = '<div class="result-head"><h3>Analyzing URL patterns…</h3><span class="pulse"></span></div><div class="score-track"><div class="score-fill" style="width:65%;animation:breath 1s infinite"></div></div>';
  await new Promise(resolve => setTimeout(resolve, 650));
  try {
    const response = await fetch("/api/scan-url", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({url:urlInput.value})});
    const data = await response.json();
    renderResult(urlResult, data, "url");
    if (data.ok) addHistory(data.domain || data.url, data.level, data.score);
  } catch {
    urlResult.classList.remove("hidden");
    urlResult.textContent = "The server could not be reached. Check that the Flask app is running.";
  } finally { setLoading(button, false, "Analyze Threat"); }
});
textForm.addEventListener("submit", async event => {
  event.preventDefault();
  const button = textForm.querySelector("button");
  button.disabled = true; button.innerHTML = "Analyzing message… <span class='pulse'></span>";
  try {
    const response = await fetch("/api/scan-text", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({text:textInput.value})});
    const data = await response.json();
    renderResult(textResult, data, "text");
    if (data.ok) addHistory("SMS / Email text", data.level, data.score);
  } catch {
    textResult.classList.remove("hidden");
    textResult.textContent = "The server could not be reached. Check that the Flask app is running.";
  } finally { button.disabled = false; button.innerHTML = "Analyze Message <span>→</span>"; }
});
