AI CyberShield starter prototype
================================

Requirements:
- Python 3.10+
- Internet is not required for the core scanner. Google Fonts may fall back to system fonts offline.

Run on Windows:
1. Extract this ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal > New Terminal.
4. Run: py -m venv .venv
5. Run: .venv\Scripts\activate
6. Run: python -m pip install -r requirements.txt
7. Run: python app.py
8. Open http://127.0.0.1:5000 in your browser.

Run on macOS/Linux:
1. python3 -m venv .venv
2. source .venv/bin/activate
3. python -m pip install -r requirements.txt
4. python app.py
5. Open http://127.0.0.1:5000

Current working features:
- Dark cinematic dashboard with animated neon-blue/cyan UI.
- URL heuristic checks with explanations.
- SMS/email text keyword checks.
- Session-only recent scan history.
- Responsive mobile layout.

Not yet implemented:
- Real ML model or trained dataset.
- Live threat-intelligence API.
- QR image decoding.
- Persistent database / user authentication.
- Real world-map threat feed.

Safety note:
This is an educational prototype. Heuristic scores are not proof that a URL/message is safe or malicious. Do not enter passwords, OTPs, or private information.
